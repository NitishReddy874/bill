import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { AuthService } from './site/auth.service';
import { Router } from '@angular/router';
import { Vendor } from './Vendor';
import { HttpServiceService } from './http-service.service';
import {Subject} from 'rxjs';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  @Output() notifyCustomer: EventEmitter<any> = new EventEmitter();
  len: number;
  ngOnInit(

  ): void {

    this.loggedIn();
    this.router.navigate(['']);
    this.httpService.getAllTypes().subscribe(
      data => {
        this.len=data.length;
        console.log(data);
        this.type = data;
      }
    );
  }
  constructor(private authService: AuthService, public router: Router, private httpService: HttpServiceService) {
  }
  title = 'billpayment';
  isLoggedIn: boolean = false;
  found1:boolean;
  found:boolean;
  type: String[];
  public click = true;
  public clickforlogin = false;
  registerClicked() {
    this.click = false;
    this.clickforlogin = true;
  }
  user(): boolean {
    if (this.authService.roletype == "admin" || this.authService.roletype == "vendor") {
      return false;
    }
    return true;
  }
  Electricity() {
    if (!this.authService.isUserLoggedIn()) {
      alert("please Login")
      this.router.navigate(['']);
    }
    else {
      for(var value of this.type){
        if(value=="Electricity"){
          console.log(value);
          this.router.navigate(['electricity']);
          break;
        }
        else if(value!="Electricity"){
          this.router.navigate(['vendornotfound']);
        }
        else{
          alert("hello")
        }
      }
    }
  }
  Recharge() {
    if (!this.authService.isUserLoggedIn()) {
      alert("please Login")
      this.router.navigate(['']);
    }
    else {
      for(var value of this.type ){
        // console.log(value);
        if(value=="Telephone"){
          this.router.navigate(['telephone']);
          break;
        }
        else if(value!="Telephone"){
          this.router.navigate(['vendornotfound']);
        }
        else{
          alert("hello")
        }
      }
    }
  }
  DTH() {
    if (!this.authService.isUserLoggedIn()) {
      alert("please Login")
      this.router.navigate(['']);
    }
    else {
      for(var value of this.type ){
        // console.log(value);
        if(value=="DTH"){
          this.router.navigate(['dth']);
          break;
        }
        else if(value!="DTH"){
          this.router.navigate(['vendornotfound']);
        }
        else{
          alert("hello")
        }
      }
    }
  }
  Insurance() {
    if (!this.authService.isUserLoggedIn()) {
      alert("please Login")
      this.router.navigate(['']);
    }
    else {
      for(var value of this.type ){
        // console.log(value);
        if(value=="Insurance"){
          this.router.navigate(['insurance']);
          break;
        }
        else if(value!="Insurance"){
          this.router.navigate(['vendornotfound']);
        }
        else{
          alert("hello")
        }
      }
    }
  }
  Tax() {
    if (!this.authService.isUserLoggedIn()) {
      alert("please Login")
      this.router.navigate(['']);
    }
    else {
      for(var value of this.type ){
        // console.log(value);
        if(value=="Tax"){
          this.router.navigate(['tax']);
          break;
        }
        else if(value!="Tax"){
          this.router.navigate(['vendornotfound']);
        }
        else{
          alert("hello")
        }
      }
    }
  }
  Loan() {
    if (!this.authService.isUserLoggedIn()) {
      alert("please Login")
      this.router.navigate(['']);
    }
    else {
      for(var value of this.type ){
        // console.log(value);
        if(value=="Loan account"){
          this.router.navigate(['loan account']);
          break;
        }
        else if(value!="Loan account"){
          this.router.navigate(['vendornotfound']);
        }
        else{
          alert("hello")
        }
      }
    }
  }
  CreditCard() {
    if (!this.authService.isUserLoggedIn()) {
      alert("please Login")
      this.router.navigate(['']);
    }
    else {
      for(var value of this.type ){
        // console.log(value);
        if(value=="Credit Card"){
          this.router.navigate(['credit card']);
          break;
        }
        else if(value!="Credit Card"){
          this.router.navigate(['vendornotfound']);
        }
        else{
          alert("hello")
        }
      }
    }
  }
  loggedIn(): boolean {
    if (this.authService.isUserLoggedIn()) {
      this.isLoggedIn = true;
      return true
    }
  }

  logout() {
    this.authService.logOut();
    this.router.navigate(['']);
  }
}
