import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/site/auth.service';
import { Bill } from 'src/app/bill';
import { HttpServiceService } from 'src/app/http-service.service';

@Component({
  selector: 'app-bill-details',
  templateUrl: './bill-details.component.html',
  styleUrls: ['./bill-details.component.css']
})
export class BillDetailsComponent implements OnInit {

  constructor(private authService: AuthService, private httpService: HttpServiceService) { }
  billList: Bill[];
  ngOnInit() {
    this.httpService.getDetailsByname(this.authService.username).subscribe(
      data => {
        console.log(this.authService.username);
        console.log(data);
        this.billList = data;
        console.log(this.billList)
      }
    )
  }
}
