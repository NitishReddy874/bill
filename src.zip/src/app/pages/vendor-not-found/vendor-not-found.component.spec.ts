import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VendorNotFoundComponent } from './vendor-not-found.component';

describe('VendorNotFoundComponent', () => {
  let component: VendorNotFoundComponent;
  let fixture: ComponentFixture<VendorNotFoundComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VendorNotFoundComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VendorNotFoundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
