import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
@Component({
  selector: 'app-vendor-not-found',
  template: `
  <div class="container">
  <br><br><br>
  <div Style="text-align: center;" *ngIf="true">
  <p Style="font-size: 25px; color: crimson;">Required Vendor Was Not Available!!!</p>
  </div>
  
  </div>
  `,
  styles: []
})
export class VendorNotFoundComponent implements OnInit {

  constructor(private router: Router,private _location: Location) { }
  // <div><button (click)="back()">Back</button><div>
  ngOnInit() {
  }
  back() {
    this._location.back();
    console.log(this._location.back());
  }
}
