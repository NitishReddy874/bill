import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './site/login/login.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { RegisterComponent } from './site/register/register.component';
import { RegisterCustomerComponent } from './site/register/register-customer/register-customer.component';
import { RegisterVendorComponent } from './site/register/register-vendor/register-vendor.component';
import { AdminComponent } from './users/admin/admin.component';
import { BasicAuthHtppInterceptorService } from './site/basic-auth-http-interceptor.service';
import { HttpServiceService } from './http-service.service';
import { ViewComponent } from './users/admin/view/view.component';
import { VendorComponent } from './users/vendor/vendor.component';
import { EditComponent } from './users/vendor/edit/edit.component';
import { CustomerComponent } from './users/customer/customer.component';
import { CreditcartComponent } from './users/vendor/creditcart/creditcart.component';
import { DthComponent } from './users/vendor/dth/dth.component';
import { ElectricityComponent } from './users/vendor/electricity/electricity.component';
import { InsuranceComponent } from './users/vendor/insurance/insurance.component';
import { LoanComponent } from './users/vendor/loan/loan.component';
import { TaxComponent } from './users/vendor/tax/tax.component';
import { TelephoneComponent } from './users/vendor/telephone/telephone.component';
import { GooglepayComponent } from './users/vendor/googlepay/googlepay.component';
import { CreditOrdebitComponent } from './users/vendor/credit-ordebit/credit-ordebit.component';
import { EWalletComponent } from './users/vendor/e-wallet/e-wallet.component';
import { NetbankingComponent } from './users/vendor/netbanking/netbanking.component';
import { PaytmComponent } from './users/vendor/paytm/paytm.component';
import { VendorNotFoundComponent } from './pages/vendor-not-found/vendor-not-found.component';
import { PaymentDoneComponent } from './pages/payment-done/payment-done.component';
import { BillDetailsComponent } from './pages/bill-details/bill-details.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    RegisterCustomerComponent,
    RegisterVendorComponent,
    AdminComponent,
    ViewComponent,
    VendorComponent,
    EditComponent,
    CustomerComponent,
    CreditcartComponent,
    DthComponent,
    ElectricityComponent,
    InsuranceComponent,
    LoanComponent,
    TaxComponent,
    TelephoneComponent,
    GooglepayComponent,
    CreditOrdebitComponent,
    EWalletComponent,
    NetbankingComponent,
    PaytmComponent,
    VendorNotFoundComponent,
    PaymentDoneComponent,
    BillDetailsComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [HttpServiceService,{
    provide: HTTP_INTERCEPTORS,
    useClass: BasicAuthHtppInterceptorService,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
