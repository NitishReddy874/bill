export interface Bill{
 username:String;
 vendortype:String;
 billno:number;
 amount:number;
 phoneno:number;
 payment:String;
}