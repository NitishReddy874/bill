export class Vendor{

    vid:number;
    regno:string;
    address:string;
    type:string;
    vnum:number;
    email:string;
    website:string;
    cid:Date;
    cvd:Date;
    yoe:Date;
    password:string;
    status:string;
    vname:string;
  }