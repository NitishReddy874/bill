import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { Vendor } from 'src/app/Vendor';
import { HttpServiceService } from 'src/app/http-service.service';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/site/auth.service';
import { Bill } from 'src/app/bill';
import { IfStmt } from '@angular/compiler';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  searchKey: string;
  vendorList: Vendor[];
  public verify = false;
  filteredvendorList: Vendor[];

  constructor(private httpService: HttpServiceService, private router: Router, private authService: AuthService) { }
  // verif():boolean {
  //   if (this.authService.isClicked()) {
  //     return true;
  //   }
  // }
  billList: Bill[];
  public click=true;
  ngOnInit() {
    this.httpService.getAllVendors().subscribe(
      data => {
        console.log(data);
        this.vendorList = data;
        this.filteredvendorList = this.vendorList;
      }
    );
    this.httpService.getDetailsByname(this.authService.username).subscribe(
      data => {
        console.log(this.authService.username);
        console.log(data);
        this.billList = data;
        console.log(this.billList)
        console.log(this.billList.findIndex[0])
      }
    )
  }
  GetDetails(){
    this.click=false;
    if(this.billList.findIndex[0]==this.authService.username){
      console.log(this.billList.findIndex[0])
      alert("user name matched!");
    }
  }
  search() {
    this.filteredvendorList = this.vendorList.filter(item => item.vname.toLocaleLowerCase().includes(this.searchKey.toLocaleLowerCase()) || item.type.toLocaleLowerCase().includes(this.searchKey.toLocaleLowerCase()));
    this.httpService.getSubject().next(this.filteredvendorList);
  }
  pay(type: String) {
    console.log(type.toLocaleLowerCase());
    this.router.navigate([type.toLocaleLowerCase()]);
  }
}
