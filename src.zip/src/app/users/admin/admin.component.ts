import { Component, OnInit } from '@angular/core';
import { HttpServiceService } from 'src/app/http-service.service';
import { Vendor } from 'src/app/Vendor';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  constructor(private httpService:HttpServiceService) { }
  adminList :Vendor[];
  ngOnInit() {
    this.httpService.getAdminList().subscribe(
      data => {
        console.log(data);
        this.adminList = data;
      }
    )
  }
  accept(vendor:Vendor){
    vendor.status = "yes";
    console.log(vendor);
    this.httpService.setVendorAccept(vendor).subscribe(
      data => {
       this.httpService.getAdminList().subscribe(
         data =>{
           this.adminList = data;
         }
       ) 
      }
    )
  }

  removeFromVendor(name:String){
    this.httpService.removeFromVendor(name).subscribe(
      data => {
        this.httpService.getAdminList().subscribe(
          data =>{
            this.adminList = data;
      })
  })
  }
  
}