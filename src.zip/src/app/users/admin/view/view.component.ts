import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { HttpServiceService } from 'src/app/http-service.service';
import { Vendor } from 'src/app/Vendor';

@Component({
  selector: 'app-view',
  templateUrl: './view.component.html',
  styleUrls: ['./view.component.css']
})
export class ViewComponent implements OnInit {
  name:string;
  vendorList:Vendor;
  constructor(private route : ActivatedRoute,private httpService:HttpServiceService) { }

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    this.name=id.toString();
    this.httpService.getAdminByName(this.name).subscribe(
      data => {
        console.log(data);
        this.vendorList = data; 
      }
    )
  }
  
}
