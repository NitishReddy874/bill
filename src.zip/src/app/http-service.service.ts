import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { AuthService } from './site/auth.service';
import { Vendor } from './Vendor';
import { Subject } from 'rxjs';
import { Bill } from './bill';

@Injectable({
  providedIn: 'root'
})

export class HttpServiceService {

  subject = new Subject<Vendor[]>();
  constructor(private http: HttpClient, private router: Router) { }

  getAdminList() {
    return this.http.get<Vendor[]>('http://localhost:8083/user-service/user');
  }
  setVendorAccept(vendor: Vendor) {
    return this.http.put('http://localhost:8083/user-service/admin/vendor', vendor);
  }
  removeFromVendor(name: String) {
    return this.http.delete('http://localhost:8083/user-service/admin/' + name);
  }
  getAdminByName(name: String) {
    return this.http.get<Vendor>('http://localhost:8083/user-service/admin/' + name);
  }
  removeVendor(name: string) {
    return this.http.delete('http://localhost:8083/user-service/vendor/' + name);
  }
  getVendorByName(name: String) {
    return this.http.get<Vendor>('http://localhost:8083/user-service/vendor/' + name);
  }
  editVendor(vendor: Vendor) {
    return this.http.put('http://localhost:8083/user-service/vendor/edit', vendor);
  }
  getDetailsByname(name: String) {
    return this.http.get<Bill[]>('http://localhost:8083/user-service/bills/' + name);
  }
  editVendors(vendor: Vendor) {
    console.log(vendor);
    this.editVendor(vendor).subscribe(
      data => {
        alert("Edited Successfully");
        this.router.navigate(['vendor']);
      }
    )
  }

  addBill(billList: Bill) {
    console.log(billList);
    this.addBillObservable(billList).subscribe(
      data => {
        console.log(billList.payment)
        var bill = billList.payment
        this.router.navigate([bill]);
      }
    )
  }
  addBillObservable(billList: Bill) {
    return this.http.post('http://localhost:8083/user-service/bill', billList);
  }
  getAllVendors() {
    return this.http.get<Vendor[]>('http://localhost:8083/user-service/user');
  }
  getAllTypes() {
    return this.http.get<String[]>('http://localhost:8083/user-service/type')
  }
  getSubject(): Subject<Vendor[]> {
    return this.subject;
  }
}
