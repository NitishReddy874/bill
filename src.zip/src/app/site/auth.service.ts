import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { User } from './User';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  roletype: string;
  username: string;
  constructor(private httpClient: HttpClient, private router: Router) { }
  validUser: boolean = false;
  authenticate(username: string, password: string): Observable<any> {
    console.log(username + " " + password);
    const headers = new HttpHeaders({ Authorization: 'Basic ' + btoa(username + ':' + password) });
    console.log(headers);
    return this.httpClient.get('http://localhost:8083/authentication-service/authenticate', { headers });
  }
  login(username: string, password: string) {
    this.authenticate(username, password).subscribe(
      (data) => {
        let token = 'Bearer ' + data.token;
        console.log(token);
        this.roletype = data.Role;
        sessionStorage.setItem('basicauth', token);
        console.log(sessionStorage.getItem('basicauth'));
        this.username = data.user;
        sessionStorage.setItem('username', username);
        console.log(sessionStorage.getItem('username'));
        if (this.roletype == "admin") {
          this.router.navigate(['admin']);
        }
        else if (this.roletype == "vendor") {
          this.router.navigate(['vendor']);
        }
        else if (this.roletype == "user") {
          this.router.navigate(['customer']);
        }
      }
    )
  }
  // public click = false;
  // isClicked(): boolean {
  //   this.click = true;
  //   return this.click;
  // }
  isUserLoggedIn(): boolean {
    let user = sessionStorage.getItem('username')
    return !(user === null)
  }

  logOut() {
    sessionStorage.removeItem('username')
  }
}
