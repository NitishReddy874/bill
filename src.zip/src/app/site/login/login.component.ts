import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public click = true;

  //public clickforlogin = false;
  registerClicked() {
    this.click = false;
    //this.clickforlogin=true;
   
  }

  loginForm:FormGroup;
  logged:string = "true";
  constructor(private router:Router,private formBuild:FormBuilder,private authService:AuthService) { }

  ngOnInit() {
    this.loginForm = this.formBuild.group({
      username: ['',[
        Validators.required
      ]],
      password: ['',[
        Validators.required
      ]]
    })
  }
  get username(){
    return this.loginForm.get('username');
  }
  get password(){
    return this.loginForm.get('password');
  }
  register(){
    this.router.navigate(['register']);
  }
  login(){
    this.authService.login(this.loginForm.value["username"],this.loginForm.value["password"]);
  }

}
