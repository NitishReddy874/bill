export interface User{
    name:string;
    password:string;
    company:string;
    address:string;
    vendor:string;
    contactNumber:number;
    email:string;
    website:string;
    cid:Date;
    cvd:Date;
    yoe:Date;
}