export interface Customer{
    userid:string;
    password:string;
    firstname:string;
    lastname:string;
    age:number;
    gender:string;
    contactNumber:number;
    email:string;
    pan:string;
    aadharNumber:string;
}