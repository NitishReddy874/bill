import { Injectable } from '@angular/core';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';
import { User } from './User';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Customer } from './Customer';
import { Bill } from '../bill';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  userExists : boolean = false;
  constructor(private router:Router,private authService : AuthService, private http : HttpClient) { }
  addVendor(userList : User){
    console.log(userList);
    this.addVendorObservable(userList).subscribe(
      data => {
        if(data){
          this.userExists =true;
        this.router.navigate(['']);}
        else{
          alert('Already exist');
          this.router.navigate(['regvendor']);
        }
           
      });
  }
  addUser(userList : Customer) {
    console.log(userList);
    this.addUserObservable(userList).subscribe(
      data => {
        this.router.navigate(['']);
      }
    )
  }
  addVendorObservable(userList : User) {
    return this.http.post('http://localhost:8083/authentication-service/vendor',userList);
  }
  addUserObservable(userList : Customer) {
    return this.http.post('http://localhost:8083/authentication-service/users',userList);
  }
}
