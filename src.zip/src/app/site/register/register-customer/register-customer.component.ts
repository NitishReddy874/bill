import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-register-customer',
  templateUrl: './register-customer.component.html',
  styleUrls: ['./register-customer.component.css']
})
export class RegisterCustomerComponent implements OnInit {

  registerForm: FormGroup;
  genders:string[] = ["Male","Female"]
  constructor(private router :Router,private formBuilder:FormBuilder,private userService :UserService) { }
  Alert(){
    alert("New user created successfully");
  }
  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstname:['',[
        Validators.required,
        Validators.pattern("^[a-zA-Z]*$"),
        Validators.minLength(1),
        Validators.maxLength(50),
      ]],
      lastname:['',[
        Validators.required,
        Validators.pattern("^[a-zA-Z]*$"),
        Validators.minLength(1),
        Validators.maxLength(50),
      ]],
      password:['',[
        Validators.required,
        Validators.maxLength(15),
        Validators.minLength(1)
      ]],
      age:['',[
        Validators.required,
        Validators.min(1),
        Validators.pattern("^[0-9]*$"),
        Validators.maxLength(2)
      ]],
      gender:['',[
        Validators.required
      ]],
      pan:['',[
        Validators.required,
        Validators.maxLength(15),
        Validators.minLength(1)
      ]],
      aadharNumber:['',[
        Validators.required,
        Validators.maxLength(15),
        Validators.minLength(1)
      ]],
      userid:['',[
        Validators.required,
        Validators.maxLength(15),
        Validators.minLength(1)
      ]],
      email:['',[
        Validators.required,
        Validators.email,
      ]],
      contactNumber:['',[
        Validators.required,
        Validators.maxLength(10),
        Validators.minLength(1),
        Validators.pattern("^[0-9]*$")
      ]]
    })
  }
  get firstname(){
    return this.registerForm.get('firstname');
  }
  get password(){
    return this.registerForm.get('password');
  }
  get lastname(){
    return this.registerForm.get('lastname');
  }
  get age(){
    return this.registerForm.get('age');
  }
  get gender(){
    return this.registerForm.get('gender');
  }
  get pan(){
    return this.registerForm.get('pan');
  }
  get aadharNumber(){
    return this.registerForm.get('aadharNumber');
  }
  get userid(){
    return this.registerForm.get('userid');
  }
  get email(){
    return this.registerForm.get('email');
  }
  get contactNumber(){
    return this.registerForm.get('contactNumber');
  }

submit(){
  this.router.navigate(['']);
}
}
