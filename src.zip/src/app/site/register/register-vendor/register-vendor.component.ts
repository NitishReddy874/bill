import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../auth.service';
import { UserService } from '../../user.service';

@Component({
  selector: 'app-register-vendor',
  templateUrl: './register-vendor.component.html',
  styleUrls: ['./register-vendor.component.css']
})
export class RegisterVendorComponent implements OnInit {
public regDone=false;
  vendors:string[] = ["Electricity","Telephone","DTH","Insurance","Tax","Credit Card","Loan account","Others"]
  registerForm: FormGroup;
  constructor(private router :Router,private formBuilder:FormBuilder,private authService:UserService) { }
  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      name:['',[
        Validators.required,
        Validators.pattern("^[a-zA-Z]*$"),
        Validators.minLength(1),
        Validators.maxLength(50),
      ]],
      company:['',[
        Validators.required,
        Validators.minLength(1),
        Validators.maxLength(50),
      ]],
      address:['',[
        Validators.required
      ]],
      vendor:['',[
        Validators.required
      ]],
      website:['',[
        Validators.required,
        Validators.maxLength(15)
      ]],
      cid:['',[
        Validators.required
      ]],
      cvd:['',[
        Validators.required
      ]],
      yoe:['',[
        Validators.required,
        ]],
      email:['',[
        Validators.required,
        Validators.email,
      ]],
      contactNumber:['',[
        Validators.required,
        Validators.pattern("^[0-9]*$"),
        Validators.maxLength(12),
        Validators.minLength(1)
      ]],
      password:['',[
        Validators.required,
        Validators.maxLength(15),
        Validators.minLength(1)
      ]],
    })
  }
  get name(){
    return this.registerForm.get('name');
  }
  get company(){
    return this.registerForm.get('company');
  }
  get address(){
    return this.registerForm.get('address');
  }
  get vendor(){
    return this.registerForm.get('vendor');
  }
  get website(){
    return this.registerForm.get('website');
  }
  get cid(){
    return this.registerForm.get('cid');
  }
  get cvd(){
    return this.registerForm.get('cvd');
  }
  get yoe(){
    return this.registerForm.get('yoe');
  }
  get email(){
    return this.registerForm.get('email');
  }
  get contactNumber(){
    return this.registerForm.get('contactNumber');
  }
  get payment(){
    return this.registerForm.get('payment');
  }
  get password(){
    return this.registerForm.get('password');
  }
  Alert(){
    alert("Vendor registered successfully");
  }
}
