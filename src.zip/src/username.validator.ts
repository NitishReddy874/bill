import { AbstractControl } from '@angular/forms';

export function ValidateName(control: AbstractControl) {
  if (!control.value.equals(control.value)) {
    return { validUrl: true };
  }
  return null;
}