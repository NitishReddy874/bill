package com.cognizant.billpayment.model;

import java.util.Date;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class Vendor {

	@Size(min = 1, max = 50, message = "Username should not be blank")
	@NotNull
	private String name;
	@Size(min = 1, max = 50, message = "Password should not be blank")
	@NotNull
	private String password;
	@Size(min = 1, max = 50, message = "Reg. No should not be blank")
	@NotNull
	private String company;
	@NotNull
	private String address;
	@NotNull
	private String vendor;
	@Size(min = 1, max = 12)
	private int contactNumber;
	@Size(min = 1, max = 15, message = "Email should not be blank")
	@NotNull
	private String email;
	@Size(min = 1, max = 15, message = "Website should not be blank")
	@NotNull
	private String website;
	@NotNull
	private Date cid;
	@NotNull
	private Date cvd;
	@NotNull
	private Date yoe;

	public String getUsername() {
		return name;
	}

	public void setName(String username) {
		this.name = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRegno() {
		return company;
	}

	public void setCompany(String regno) {
		this.company = regno;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getVendorType() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public int getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(int contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public Date getCid() {
		return cid;
	}

	public void setCid(Date cid) {
		this.cid = cid;
	}

	public Date getCvd() {
		return cvd;
	}

	public void setCvd(Date cvd) {
		this.cvd = cvd;
	}

	public Date getYoe() {
		return yoe;
	}

	public void setYoe(Date yoe) {
		this.yoe = yoe;
	}

}
