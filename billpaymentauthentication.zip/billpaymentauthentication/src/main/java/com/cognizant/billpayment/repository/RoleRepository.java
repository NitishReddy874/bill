package com.cognizant.billpayment.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.billpayment.model.Role;

@Repository
public interface RoleRepository extends JpaRepository<Role, String> {

	@Query("From Role where ro_id = ?1")
	Role findById(int id);
}
