package com.cognizant.billpayment.controller;

import java.util.HashSet;
import java.util.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.billpayment.model.Customer;
import com.cognizant.billpayment.model.Role;
import com.cognizant.billpayment.model.User;
import com.cognizant.billpayment.model.Users;
import com.cognizant.billpayment.model.Vendor;
import com.cognizant.billpayment.model.Vendors;
import com.cognizant.billpayment.repository.CustomerRepository;
import com.cognizant.billpayment.repository.RoleRepository;
import com.cognizant.billpayment.repository.UserRepository;
import com.cognizant.billpayment.repository.VendorRepository;



@RestController
@CrossOrigin
public class UserController {

	@Autowired
	RoleRepository roleRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	CustomerRepository customerRepository;
	@Autowired
	VendorRepository vendorRepository;
	
	@PostMapping("/users")
	public String signup(@RequestBody User userlist) {
		Users user = userRepository.findByUsername(userlist.getUserID());
		if (user == null) {
			Users users = new Users();
			users.setUsername(userlist.getUserID());
			users.setPassword(passwordEncoder().encode(userlist.getPassword()));
			Role role = roleRepository.findById(2);
			Set<Role> roleList = new HashSet<>();
			roleList.add(role);
			users.setRoleList(roleList);
			userRepository.save(users);
			Customer customer = new Customer();
			customer.setFirstname(userlist.getFirstName());
			customer.setLastname(userlist.getLastName());
			customer.setAge(userlist.getAge());
			customer.setAadhar(userlist.getAadhar());
			customer.setCustomerid(userlist.getUserID());
			customer.setEmail(userlist.getEmail());
			customer.setNumber(userlist.getContactNumber());
			customer.setPan(userlist.getPan());
			customer.setPassword(userlist.getPassword());
			customer.setGender(userlist.getGender());
			customerRepository.save(customer);
			return "true";
		}
		return "false";
	}

	@PostMapping("/vendor")
	public String signupVendor(@RequestBody Vendor userlist) {
		Users user = userRepository.findByUsername(userlist.getUsername());
		if (user == null) {
			Users users = new Users();
			users.setUsername(userlist.getUsername());
			users.setPassword(passwordEncoder().encode(userlist.getPassword()));
			Role role = roleRepository.findById(3);
			Set<Role> roleList = new HashSet<>();
			roleList.add(role);
			users.setRoleList(roleList);
			userRepository.save(users);
			Vendors vendors = new Vendors();
			vendors.setAddress(userlist.getAddress());
			vendors.setCid(userlist.getCid());
			vendors.setCvd(userlist.getCvd());
			vendors.setEmail(userlist.getEmail());
			vendors.setPassword(userlist.getPassword());
			vendors.setRegno(userlist.getRegno());
			vendors.setType(userlist.getVendorType());
			vendors.setVname(userlist.getUsername());
			vendors.setVnum(userlist.getContactNumber());
			vendors.setWebsite(userlist.getWebsite());
			vendors.setYoe(userlist.getYoe());
			vendorRepository.save(vendors);
			return "true";
		}
		return "false";
	}
	
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
}
