package com.cognizant.billpayment.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.billpayment.model.Vendors;

@Repository
public interface VendorRepository extends JpaRepository<Vendors, String> {

	Vendors findByUsername(String user);
}
