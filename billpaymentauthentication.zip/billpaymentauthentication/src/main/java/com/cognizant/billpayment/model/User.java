package com.cognizant.billpayment.model;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class User {

	@Size(min = 1, max = 50, message = "UserID should not be blank")
	@NotNull
	private String userid;
	@NotNull
	private String password;
	@Size(min = 1, max = 50, message = "Firstname should not be blank")
	@NotNull
	private String firstname;
	@Size(min = 1, max = 50, message = "Lastname should not be blank")
	@NotNull
	private String lastname;
	@Size(min = 1, max = 2, message = "Age should not be blank")
	@NotNull
	private int age;
	@NotNull
	private String gender;
	@Size(min = 1, max = 10)
	private int contactNumber;
	@NotNull
	private String email;
	@Size(min = 1, max = 50, message = "Pan should not be blank")
	@NotNull
	private String pan;
	@Size(min = 1, max = 50, message = "Aadhar number should not be blank")
	@NotNull
	private String aadharNumber;

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(int contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public String getAadhar() {
		return aadharNumber;
	}

	public void setAadharNumber(String aadhar) {
		this.aadharNumber = aadhar;
	}

	public String getUserID() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstname;
	}

	public void setFirstname(String firstName) {
		this.firstname = firstName;
	}

	public String getLastName() {
		return lastname;
	}

	public void setLastname(String secondName) {
		this.lastname = secondName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

}
