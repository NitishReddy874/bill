package com.cognizant.billpayment.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.billpayment.model.Users;

public interface UserRepository extends JpaRepository<Users, String> {

	Users findByUsername(String user);
}
