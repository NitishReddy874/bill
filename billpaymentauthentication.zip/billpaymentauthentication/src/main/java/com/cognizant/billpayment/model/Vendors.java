package com.cognizant.billpayment.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "vendor")
public class Vendors {

	@Id
	@Column(name = "vid")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int vid;
	@Column(name = "vname")
	private String username;
	@Column(name = "regno")
	private String regno;
	@Column(name = "address")
	private String address;
	@Column(name = "type")
	private String type;
	@Column(name = "vnum")
	private int vnum;
	@Column(name = "email")
	private String email;
	@Column(name = "website")
	private String website;
	@Column(name = "cid")
	private Date cid;
	@Column(name = "cvd")
	private Date cvd;
	@Column(name = "yoe")
	private Date yoe;
	@Column(name = "password")
	private String password;
	@Column(name = "status")
	private String status;

	public int getVid() {
		return vid;
	}

	public void setVid(int vid) {
		this.vid = vid;
	}

	public String getVname() {
		return username;
	}

	public void setVname(String vname) {
		this.username = vname;
	}

	public String getRegno() {
		return regno;
	}

	public void setRegno(String regno) {
		this.regno = regno;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getVnum() {
		return vnum;
	}

	public void setVnum(int vnum) {
		this.vnum = vnum;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getWebsite() {
		return website;
	}

	public void setWebsite(String website) {
		this.website = website;
	}

	public Date getCid() {
		return cid;
	}

	public void setCid(Date cid) {
		this.cid = cid;
	}

	public Date getCvd() {
		return cvd;
	}

	public void setCvd(Date cvd) {
		this.cvd = cvd;
	}

	public Date getYoe() {
		return yoe;
	}

	public void setYoe(Date yoe) {
		this.yoe = yoe;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
