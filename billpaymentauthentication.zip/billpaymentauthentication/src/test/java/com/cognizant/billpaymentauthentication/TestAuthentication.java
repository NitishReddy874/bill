package com.cognizant.billpaymentauthentication;

import static org.junit.Assert.*;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;

import com.cognizant.billpayment.model.Users;
import com.cognizant.billpayment.repository.UserRepository;
import com.cognizant.billpayment.security.AppUser;
import com.cognizant.billpayment.security.AppUserDetailsService;

public class TestAuthentication {

	@Autowired
	AppUserDetailsService userDetailsService;
	@Autowired
	UserRepository userRepository;

	@Test
	public void userLogin() {
		Users user = userRepository.findByUsername("admin");
		AppUser appUser = new AppUser(user);
		UserDetails userDetails = (UserDetails) userDetailsService.loadUserByUsername("admin");
		assertEquals(userDetails.getPassword(), appUser.getPassword());
	}

	@Test
	public void login() {
		Users user = userRepository.findByUsername("finny");
		AppUser appUser = new AppUser(user);
		UserDetails userDetails = (UserDetails) userDetailsService.loadUserByUsername("finny");
		assertEquals(userDetails.getPassword(), appUser.getPassword());
	}

}
