package com.cognizant.billpaymentauthentication;

import org.junit.Test;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class BillpaymentauthenticationApplicationTests {

	@Test
	public void contextLoads() {
	}

}
