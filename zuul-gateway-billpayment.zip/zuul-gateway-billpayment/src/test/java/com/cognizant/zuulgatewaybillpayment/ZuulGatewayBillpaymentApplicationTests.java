package com.cognizant.zuulgatewaybillpayment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuulGatewayBillpaymentApplicationTests {

	@Test
	void contextLoads() {
	}

}
