package com.cognizant.billpayment.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cognizant.billpayment.model.Users;
import com.cognizant.billpayment.model.Vendors;
import com.cognizant.billpayment.repository.UserRepository;
import com.cognizant.billpayment.repository.VendorRepository;

@Component
public class AdminDao {

	@Autowired
	VendorRepository vendorRepository;
	@Autowired
	UserRepository userRepository;

	List<Vendors> vendorList = null;

	public List<Vendors> getAdminList() {
		vendorList = vendorRepository.findAll();
		List<Vendors> list = new ArrayList<>();
		for (Vendors vendors : vendorList) {
			if (vendors.getStatus() == null) {
				list.add(vendors);
			}
		}
		return list;
	}

	public void setVendorAccept(Vendors vendors) {
		// TODO Auto-generated method stub
		vendorRepository.save(vendors);

	}

	public void deleteVendor(String id) {
		// TODO Auto-generated method stub
		Vendors vendors = vendorRepository.findByUsername(id);
		vendorRepository.delete(vendors);
		Users users = userRepository.findByUsername(id);
		userRepository.delete(users);
	}

	public List<Vendors> getVendorList() {
		// TODO Auto-generated method stub
		vendorList = vendorRepository.findAll();
		for (Vendors vendors : vendorList) {
		}
		return vendorList;
	}

	public List<Vendors> getUserList() {
		// TODO Auto-generated method stub
		vendorList = vendorRepository.findAll();
		List<Vendors> list = new ArrayList<>();
		for (Vendors vendors : vendorList) {
			if (vendors.getStatus() != null) {
				list.add(vendors);
			}
		}
		return list;
	}

	public Vendors getAdminByName(String id) {
		// TODO Auto-generated method stub
		Vendors vendors = vendorRepository.findByUsername(id);
		return vendors;
	}

	public String editVendor(Vendors vendors) {
		// TODO Auto-generated method stub
		vendorRepository.save(vendors);
		return "true";
	}
}
