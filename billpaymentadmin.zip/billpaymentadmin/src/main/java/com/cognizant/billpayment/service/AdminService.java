package com.cognizant.billpayment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.billpayment.dao.AdminDao;
import com.cognizant.billpayment.model.Vendors;

@Service
public class AdminService {

	@Autowired
	AdminDao adminDao;

	public List<Vendors> getAdminList() {
		return adminDao.getAdminList();
	}

	public void setVendorAccept(Vendors vendors) {
		// TODO Auto-generated method stub
		adminDao.setVendorAccept(vendors);
	}

	public void deleteVendor(String id) {
		// TODO Auto-generated method stub
		adminDao.deleteVendor(id);
	}

	public List<Vendors> getVendorList() {
		// TODO Auto-generated method stub
		return adminDao.getVendorList();
	}

	public List<Vendors> getUserList() {
		// TODO Auto-generated method stub
		return adminDao.getUserList();
	}

	public Vendors getAdminByName(String id) {
		// TODO Auto-generated method stub
		return adminDao.getAdminByName(id);
	}

	public String editVendor(Vendors vendors) {
		// TODO Auto-generated method stub
		return adminDao.editVendor(vendors);
	}
}
