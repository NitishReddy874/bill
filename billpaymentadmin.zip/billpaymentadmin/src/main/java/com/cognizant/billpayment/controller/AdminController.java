package com.cognizant.billpayment.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.billpayment.model.Bill;
import com.cognizant.billpayment.model.Bills;

import com.cognizant.billpayment.model.Role;

import com.cognizant.billpayment.model.Users;
import com.cognizant.billpayment.model.Vendors;
import com.cognizant.billpayment.repository.BillRepository;
import com.cognizant.billpayment.repository.UserRepository;
import com.cognizant.billpayment.repository.VendorRepository;
import com.cognizant.billpayment.service.AdminService;

@CrossOrigin
@RestController
public class AdminController {

	@Autowired
	AdminService adminService;
	@Autowired
	UserRepository userRepository;
	@Autowired
	VendorRepository vendorRepository;

	@Autowired
	BillRepository billRepository;

	@GetMapping("/user")
	public List<Vendors> getList() {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String name = authentication.getName();
		String[] username = name.split(":");
		Users users = userRepository.findByUsername(username[0]);
		Set<Role> roles = users.getRoleList();
		String[] roleTypes = roles.toString().split(",");
		String[] roleType = roleTypes[1].split("=");
		String[] role = roleType[1].split("]");
		System.out.println(role[0]);
		if (role[0].equals("admin")) {
			return getAdminList();
		} else if (role[0].equals("vendor")) {
			return getVendorList();
		} else if (role[0].equals("user")) {
			return getUserList();
		} else {
			return null;
		}
	}

	@PostMapping("/bill")
	public String signup(@RequestBody Bills billList) {
		Bill bills = new Bill();
		bills.setUsername(billList.getUsername());
		bills.setVendortype(billList.getVendortype());
		bills.setBillno(billList.getBillno());
		bills.setAmount(billList.getAmount());
		bills.setPhoneno(billList.getPhoneno());
		bills.setPayment(billList.getPayment());
		billRepository.save(bills);
		return "true";
	}

	@GetMapping("/bills/{name}")
	public List<Bill> getBillDetails(@PathVariable String name) {
		return billRepository.getDetails(name);
	}

	private List<Vendors> getUserList() {
		// TODO Auto-generated method stub
		return adminService.getUserList();
	}

	private List<Vendors> getVendorList() {
		// TODO Auto-generated method stub
		return adminService.getVendorList();
	}

	public List<Vendors> getAdminList() {
		return adminService.getAdminList();
	}

	@GetMapping("/type")
	public List<String> getTypes() {
		return vendorRepository.findType();

	}

	@PutMapping("/admin/vendor")
	public void setVendorAccept(@RequestBody Vendors vendors) {
		adminService.setVendorAccept(vendors);
	}

	@DeleteMapping("/admin/{id}")
	public void deleteVendor(@PathVariable String id) {
		adminService.deleteVendor(id);
	}

	@GetMapping("/admin/{id}")
	public Vendors getAdminByName(@PathVariable String id) {
		return adminService.getAdminByName(id);
	}

	@DeleteMapping("/vendor/{id}")
	public void removeVendor(@PathVariable String id) {
		adminService.deleteVendor(id);
	}

	@GetMapping("/vendor/{id}")
	public Vendors getVendorByName(@PathVariable String id) {
		return adminService.getAdminByName(id);
	}

	@PutMapping("/vendor/edit")
	public String editVendor(@RequestBody Vendors vendors) {
		return adminService.editVendor(vendors);
	}
}
