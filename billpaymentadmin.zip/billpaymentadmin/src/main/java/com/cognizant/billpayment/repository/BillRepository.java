package com.cognizant.billpayment.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cognizant.billpayment.model.Bill;
import com.cognizant.billpayment.model.Bills;

@Repository
public interface BillRepository extends JpaRepository<Bill, String> {

	Bill findByUsername(String name);

	@Query(value = "select * from bill where username= :name", nativeQuery = true)
	List<Bill> getDetails(@Param(value = "name") String name);

}
