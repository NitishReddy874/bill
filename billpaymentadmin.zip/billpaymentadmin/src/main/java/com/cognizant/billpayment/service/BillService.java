package com.cognizant.billpayment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.billpayment.model.Bill;
import com.cognizant.billpayment.repository.BillRepository;

@Service
public class BillService {

	@Autowired
	BillRepository billRepository;

	public List<Bill> getBillDetails(String name) {
		return null;
	}

}
