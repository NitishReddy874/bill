package com.cognizant.billpaymentadmin;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BillpaymentadminApplicationTests {

	@Test
	void contextLoads() {
	}

}
