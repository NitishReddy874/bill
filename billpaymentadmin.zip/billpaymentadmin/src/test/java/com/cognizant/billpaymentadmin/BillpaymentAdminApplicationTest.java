package com.cognizant.billpaymentadmin;

import static org.junit.Assert.*;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

import com.cognizant.billpayment.dao.AdminDao;
import com.cognizant.billpayment.model.Vendors;
import com.cognizant.billpayment.repository.VendorRepository;
import com.cognizant.billpayment.service.AdminService;

@SpringBootTest
public class BillpaymentAdminApplicationTest {

	@InjectMocks
	AdminService adminService;

	@Mock
	AdminDao adminDao;

	@Before
	public void init() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetAdminList() {
		Vendors vendorsOne = new Vendors();
		vendorsOne.setVid(1);
		vendorsOne.setVname("Finny");
		vendorsOne.setRegno("2");
		vendorsOne.setAddress("bhimavaram");
		vendorsOne.setType("Telephone");
		vendorsOne.setVnum(9603340);
		vendorsOne.setEmail("finny@gmail.com");
		vendorsOne.setWebsite("finny.com");
		vendorsOne.setCid(new Date());
		vendorsOne.setCvd(new Date());
		vendorsOne.setYoe(new Date());
		vendorsOne.setPassword("pwd");
		vendorsOne.setStatus(null);

		List<Vendors> vendors = new ArrayList<>();
		vendors.add(vendorsOne);

		when(adminDao.getAdminList()).thenReturn(vendors);

		// test
		List<Vendors> testVendors = adminDao.getAdminList();

		assertEquals(1, testVendors.size());
		for (Vendors vendor : testVendors) {
			assertEquals("Finny", vendor.getVname());
		}
	}

	@Test
	public void testGetAdminFailureList() {
		Vendors vendorsOne = new Vendors();
		vendorsOne.setVid(1);
		vendorsOne.setVname("Finny");
		vendorsOne.setRegno("2");
		vendorsOne.setAddress("bhimavaram");
		vendorsOne.setType("Telephone");
		vendorsOne.setVnum(9603340);
		vendorsOne.setEmail("finny@gmail.com");
		vendorsOne.setWebsite("finny.com");
		vendorsOne.setCid(new Date());
		vendorsOne.setCvd(new Date());
		vendorsOne.setYoe(new Date());
		vendorsOne.setPassword("pwd");
		vendorsOne.setStatus("yes");

		List<Vendors> vendors = new ArrayList<>();
		if (vendorsOne.getStatus() == null)
			vendors.add(vendorsOne);

		when(adminDao.getAdminList()).thenReturn(vendors);

		// test
		List<Vendors> testVendors = adminDao.getAdminList();

		assertEquals(1, testVendors.size());
		for (Vendors vendor : testVendors) {
			assertEquals("Finny", vendor.getVname());
		}
	}

	@Test
	public void testGetVendorList() {
		Vendors vendorsOne = new Vendors();
		vendorsOne.setVid(1);
		vendorsOne.setVname("Finny");
		vendorsOne.setRegno("2");
		vendorsOne.setAddress("bhimavaram");
		vendorsOne.setType("Telephone");
		vendorsOne.setVnum(9603340);
		vendorsOne.setEmail("finny@gmail.com");
		vendorsOne.setWebsite("finny.com");
		vendorsOne.setCid(new Date());
		vendorsOne.setCvd(new Date());
		vendorsOne.setYoe(new Date());
		vendorsOne.setPassword("pwd");
		vendorsOne.setStatus("yes");

		List<Vendors> vendors = new ArrayList<>();
		vendors.add(vendorsOne);

		when(adminDao.getVendorList()).thenReturn(vendors);

		// test
		List<Vendors> testVendors = adminDao.getVendorList();

		assertEquals(1, testVendors.size());
		for (Vendors vendor : testVendors) {
			assertEquals("Finny", vendor.getVname());
		}
	}

	@Test
	public void testGetUserList() {
		Vendors vendorsOne = new Vendors();
		vendorsOne.setVid(1);
		vendorsOne.setVname("Finny");
		vendorsOne.setRegno("2");
		vendorsOne.setAddress("bhimavaram");
		vendorsOne.setType("Telephone");
		vendorsOne.setVnum(9603340);
		vendorsOne.setEmail("finny@gmail.com");
		vendorsOne.setWebsite("finny.com");
		vendorsOne.setCid(new Date());
		vendorsOne.setCvd(new Date());
		vendorsOne.setYoe(new Date());
		vendorsOne.setPassword("pwd");
		vendorsOne.setStatus("yes");

		List<Vendors> vendors = new ArrayList<>();
		if (vendorsOne.getStatus() == "yes")
			vendors.add(vendorsOne);

		when(adminDao.getUserList()).thenReturn(vendors);

		// test
		List<Vendors> testVendors = adminDao.getUserList();

		assertEquals(1, testVendors.size());
		for (Vendors vendor : testVendors) {
			assertEquals("Finny", vendor.getVname());
		}
	}

	@Test
	public void testGetUserFailureList() {
		Vendors vendorsOne = new Vendors();
		vendorsOne.setVid(1);
		vendorsOne.setVname("Finny");
		vendorsOne.setRegno("2");
		vendorsOne.setAddress("bhimavaram");
		vendorsOne.setType("Telephone");
		vendorsOne.setVnum(9603340);
		vendorsOne.setEmail("finny@gmail.com");
		vendorsOne.setWebsite("finny.com");
		vendorsOne.setCid(new Date());
		vendorsOne.setCvd(new Date());
		vendorsOne.setYoe(new Date());
		vendorsOne.setPassword("pwd");
		vendorsOne.setStatus(null);

		List<Vendors> vendors = new ArrayList<>();
		if (vendorsOne.getStatus() == "yes")
			vendors.add(vendorsOne);

		when(adminDao.getUserList()).thenReturn(vendors);

		// test
		List<Vendors> testVendors = adminDao.getUserList();

		assertEquals(1, testVendors.size());
		for (Vendors vendor : testVendors) {
			assertEquals("Finny", vendor.getVname());
		}
	}

}
