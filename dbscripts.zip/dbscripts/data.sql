use bill_payment;



insert into user values(1,'admin',' $2a$10$R/lZJuT9skteNmAku9Y7aeutxbOKstD5xE5bHOf74M2PHZipyt3yK');



insert into role values(1,'admin');
insert into role values(2,'user');
insert into role values(3,'vendor');



insert into user_role values(1,1,1);
