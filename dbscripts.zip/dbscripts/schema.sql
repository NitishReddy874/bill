-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema bill_payment
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema bill_payment
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `bill_payment` DEFAULT CHARACTER SET utf8 ;
USE `bill_payment` ;

-- -----------------------------------------------------
-- Table `bill_payment`.`customer`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bill_payment`.`customer` (
  `cid` INT(11) NOT NULL AUTO_INCREMENT,
  `firstname` VARCHAR(50) NULL DEFAULT NULL,
  `lastname` VARCHAR(50) NULL DEFAULT NULL,
  `age` INT(11) NULL DEFAULT NULL,
  `gender` VARCHAR(45) NULL DEFAULT NULL,
  `cnumber` INT(11) NULL DEFAULT NULL,
  `email` VARCHAR(15) NULL DEFAULT NULL,
  `pan` VARCHAR(50) NULL DEFAULT NULL,
  `aadhar` VARCHAR(50) NULL DEFAULT NULL,
  `customer_id` VARCHAR(50) NULL DEFAULT NULL,
  `pass` VARCHAR(200) NULL DEFAULT NULL,
  PRIMARY KEY (`cid`))
ENGINE = InnoDB
AUTO_INCREMENT = 11
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bill_payment`.`role`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bill_payment`.`role` (
  `ro_id` INT(11) NOT NULL AUTO_INCREMENT,
  `ro_name` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`ro_id`))
ENGINE = InnoDB
AUTO_INCREMENT = 4
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bill_payment`.`user`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bill_payment`.`user` (
  `sno` INT(11) NOT NULL AUTO_INCREMENT,
  `user_id` VARCHAR(50) NULL DEFAULT NULL,
  `user_pass` VARCHAR(200) NULL DEFAULT NULL,
  PRIMARY KEY (`sno`))
ENGINE = InnoDB
AUTO_INCREMENT = 37
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bill_payment`.`user_role`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bill_payment`.`user_role` (
  `ur_id` INT(11) NOT NULL AUTO_INCREMENT,
  `ur_us_id` VARCHAR(45) NULL DEFAULT NULL,
  `ur_ro_id` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`ur_id`))
ENGINE = InnoDB
AUTO_INCREMENT = 38
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bill_payment`.`vendor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bill_payment`.`vendor` (
  `vid` INT(11) NOT NULL AUTO_INCREMENT,
  `vname` VARCHAR(50) NULL DEFAULT NULL,
  `regno` VARCHAR(50) NULL DEFAULT NULL,
  `address` VARCHAR(100) NULL DEFAULT NULL,
  `type` VARCHAR(50) NULL DEFAULT NULL,
  `vnum` INT(10) NULL DEFAULT NULL,
  `email` VARCHAR(15) NULL DEFAULT NULL,
  `website` VARCHAR(15) NULL DEFAULT NULL,
  `cid` DATE NULL DEFAULT NULL,
  `cvd` DATE NULL DEFAULT NULL,
  `yoe` DATE NULL DEFAULT NULL,
  `password` VARCHAR(200) NULL DEFAULT NULL,
  `status` VARCHAR(4) NULL DEFAULT NULL,
  PRIMARY KEY (`vid`))
ENGINE = InnoDB
AUTO_INCREMENT = 24
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bill_payment`.`bill`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bill_payment`.`bill` (
  `bill_id` INT NOT NULL AUTO_INCREMENT,
  `username` VARCHAR(45) NULL,
  `vendortype` VARCHAR(45) NULL,
  `billno` INT NULL,
  `amount` INT NULL,
  `phoneno` INT NULL,
  `payment` VARCHAR(45) NULL,
  PRIMARY KEY (`bill_id`))
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
